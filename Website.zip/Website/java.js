
function checkEvenOrOdd() {
    var number = parseInt(prompt("Enter a number:"));
    var result = number % 2 === 0 ? "Even" : "Odd";
    document.getElementById("result").textContent = "The number is " + result + ".";
}